// Random math events and banner handling
(function(){
  const G = window.Game;
  const el = G.el;

  function handleEvents(){
    const now = performance.now();
    if(G.state.event && now > G.state.event.until){
      endEvent();
    }
    if(!G.state.event){
      if(Math.random()<0.01){
        if(Math.random()<0.5) startGoldenRatio();
        else startEuler();
      }
    }
    if(G.state.event){
      const remain = Math.max(0, (G.state.event.until - now)/1000);
      el('#eventTime').textContent = `（残り ${remain.toFixed(0)}s）`;
    }
  }

  function startGoldenRatio(){
    const dur = 18*1000;
    G.state.event = {type:'phi', until: performance.now()+dur, label:'黄金比ボーナスタイム', detail:'生産 ×1.618'};
    G.state.cpsBonusMult *= 1.618;
    showBanner('黄金比ボーナスタイム', '毎秒生産 ×1.618');
  }
  function startEuler(){
    const dur = 12*1000;
    G.state.event = {type:'euler', until: performance.now()+dur, label:'オイラーの公式', detail:'クリック ×2'};
    G.state.clickBonusMult *= 2;
    showBanner('オイラーの公式：e^{iπ}+1=0', 'クリック獲得 ×2');
  }
  function endEvent(){
    if(!G.state.event) return;
    if(G.state.event.type==='phi') G.state.cpsBonusMult /= 1.618;
    if(G.state.event.type==='euler') G.state.clickBonusMult /= 2;
    G.state.event = null;
    hideBanner();
  }
  function showBanner(title, desc){
    el('#eventTitle').textContent = title;
    el('#eventDesc').textContent = '— ' + desc;
    el('#eventBanner').style.display = 'flex';
  }
  function hideBanner(){ el('#eventBanner').style.display = 'none'; }

  // expose
  G.handleEvents = handleEvents;
})();