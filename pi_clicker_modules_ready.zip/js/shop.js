// Shop: rendering & purchases
(function(){
  const G = window.Game;
  const el = G.el;
  const shopEl = el('#shop');
  const order = ['click','spirit','trig','prime','fractal','series'];

  function renderShop(){
    shopEl.innerHTML = '';
    for(const key of order){
      const it = G.state.items[key];
      const owned = (it.type==='click')? it.level : (it.count||0);
      const cost = G.nextCost(it);
      const can = G.state.pi >= cost;

      const item = document.createElement('div');
      item.className = 'item' + (can? ' canbuy':'');
      item.dataset.key = key;

      item.innerHTML = `
        <div>
          <h4>${it.name} <span class="small">×${owned}</span></h4>
          <div class="desc">${it.desc}</div>
          <div class="meta">
            ${it.type==='gen' ? `生産: <strong>毎秒 π×${G.fmt(it.cps)}</strong>` : `効果: <strong>クリック +π×1</strong>`}
          </div>
        </div>
        <div class="right">
          <div class="small">価格: <strong>${"π×"+G.fmt(cost)}</strong></div>
          <button ${can?'':'disabled'} data-buy="${key}">購入</button>
        </div>
      `;
      shopEl.appendChild(item);
    }
  }

  shopEl.addEventListener('click', e=>{
    const btn = e.target.closest('button[data-buy]');
    if(!btn) return;
    const key = btn.dataset.buy;
    const it = G.state.items[key];
    const cost = G.nextCost(it);
    if(G.state.pi < cost) return;
    // spend
    G.state.pi -= cost;
    if(it.type==='click'){
      it.level++; G.state.clickLevel++; G.state.clickValue += 1;
    }else{
      it.count = (it.count||0) + 1;
      G.recalcCps();
      if(G.onSpecialAnimation) G.onSpecialAnimation(key);
    }
    if(G.onPurchaseToast) G.onPurchaseToast(it);
    renderShop();
    G.updateTop();
  });

  // affordability highlight
  setInterval(()=>{
    document.querySelectorAll('#shop .item').forEach(div=>{
      const key = div.dataset.key;
      const it = G.state.items[key];
      const cost = G.nextCost(it);
      if(G.state.pi >= cost) div.classList.add('canbuy'); else div.classList.remove('canbuy');
    });
  }, 200);

  // expose
  G.renderShop = renderShop;
  // initial
  renderShop();
})();