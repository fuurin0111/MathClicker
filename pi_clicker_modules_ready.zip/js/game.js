// Core game/state & shared helpers
(function(){
  const el = s => document.querySelector(s);
  const fmt = n => {
    if(!isFinite(n)) return "∞";
    const abs = Math.abs(n);
    const units = ["","K","M","B","T","Qa","Qi","Sx","Sp","Oc","No","De"];
    let u=0, val = n;
    while(Math.abs(val)>=1000 && u<units.length-1){ val/=1000; u++; }
    return (Math.sign(n)<0?"-":"") + (Math.abs(val)>=100? val.toFixed(0) : (Math.abs(val)>=10? val.toFixed(1) : val.toFixed(2))) + units[u];
  };
  const fmtPi = n => "π×" + fmt(n);

  const state = {
    pi: 0,
    totalPi: 0,
    clickValue: 1,
    clickLevel: 0,
    cpsBase: 0,
    cpsBonusMult: 1,
    clickBonusMult: 1,
    totalClicks: 0,
    primesDiscovered: 0,
    maxPiDigits: 0,
    event: null,
    items: {
      click: { key:'click', name:'π精度強化', baseCost:15, growth:1.7, level:0, desc:'1クリックの獲得量を +1π', type:'click' },
      spirit: { key:'spirit', name:'π精霊', baseCost:100, growth:1.15, count:0, cps:1, desc:'円の守護者が円周率の神秘を解き放つ', type:'gen' },
      trig: { key:'trig', name:'三角関数研究所', baseCost:1100, growth:1.15, count:0, cps:8, desc:'白衣の数学者が sin, cos, tan を研究中', type:'gen' },
      prime: { key:'prime', name:'素数ハンター', baseCost:12000, growth:1.15, count:0, cps:47, desc:'数の森を探索し、素数の秘宝を発見する', type:'gen' },
      fractal: { key:'fractal', name:'フラクタル庭園', baseCost:130000, growth:1.15, count:0, cps:260, desc:'自己相似図形を育てる数学の庭師', type:'gen' },
      series: { key:'series', name:'無限級数の修道士', baseCost:1400000, growth:1.15, count:0, cps:1400, desc:'無限級数を唱え続ける数学僧', type:'gen' },
    }
  };

  function nextCost(item){
    if(item.type==='click'){
      return Math.ceil(item.baseCost * Math.pow(item.growth, item.level));
    }
    return Math.ceil(item.baseCost * Math.pow(item.growth, item.count||0));
  }

  function recalcCps(){
    const it = state.items;
    state.cpsBase =
      it.spirit.count * it.spirit.cps +
      it.trig.count * it.trig.cps +
      it.prime.count * it.prime.cps +
      it.fractal.count * it.fractal.cps +
      it.series.count * it.series.cps;
  }

  function addPi(amount){
    state.pi += amount;
    state.totalPi += Math.max(0, amount);
  }

  function spendPi(cost){
    if(state.pi >= cost){ state.pi -= cost; return true; }
    return false;
  }

  function updateTop(){
    const cps = state.cpsBase * state.cpsBonusMult;
    el('#scorePi').textContent = fmtPi(state.pi);
    el('#scoreCps').textContent = '毎秒 ' + fmtPi(cps);
    el('#bonusLabel').textContent = `倍率 ×${(state.cpsBonusMult*state.clickBonusMult).toFixed(2)}`;
    el('#statClicks').textContent = state.totalClicks.toString();
    el('#statTotal').textContent = fmtPi(state.totalPi);
  }

  // Public API
  window.Game = {
    el, fmt, fmtPi,
    state, nextCost, recalcCps, addPi, spendPi, updateTop,
    onPurchaseToast: null,
    onSpecialAnimation: null,
    handleEvents: null,
    refreshModals: null,
    renderShop: null,
    start(){
      // Start the main tick after all modules are loaded and UI is ready
      this.state.lastTick = performance.now();
      this._tick = setInterval(()=>{
        const now = performance.now();
        const dt = Math.min(0.2, (now - this.state.lastTick)/1000);
        this.state.lastTick = now;
        const cps = this.state.cpsBase * this.state.cpsBonusMult;
        this.addPi(cps * dt);
        this.updateTop();
        if(this.handleEvents) this.handleEvents();
        if(this.renderShop) this.renderShop();
      },100);
    }
  };
})();