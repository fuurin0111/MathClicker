// UI: clicks, effects, toast, modals, achievements, start
(function(){
  const G = window.Game;
  const el = G.el;

  /* ----- Click handling & effects ----- */
  const effectsLayer = el('#effectsLayer');
  const btn = el('#piButton');

  function clickGain(ev){
    const rect = btn.getBoundingClientRect();
    const x = ev.clientX - rect.left, y = ev.clientY - rect.top;
    const gain = G.state.clickValue * G.state.clickBonusMult;
    G.addPi(gain);
    G.state.totalClicks++;

    // floating text
    const ft = document.createElement('div');
    ft.className = 'float-text';
    ft.textContent = `+π×${G.fmt(gain)}`;
    ft.style.left = ev.clientX + 'px';
    ft.style.top = ev.clientY + 'px';
    ft.style.transform = 'translate(-50%,0)';
    document.body.appendChild(ft);
    setTimeout(()=>ft.remove(), 900);

    // ripple
    const rp = document.createElement('div');
    rp.className = 'ripple';
    rp.style.left = x + 'px';
    rp.style.top = y + 'px';
    effectsLayer.appendChild(rp);
    setTimeout(()=>rp.remove(), 600);

    G.updateTop();
    if(G.renderShop) G.renderShop();
  }

  btn.addEventListener('click', clickGain);
  btn.addEventListener('keydown', (e)=>{
    if(e.key===' '||e.key==='Enter'){ e.preventDefault(); btn.click(); }
  });

  /* ----- Toast facts ----- */
  const facts = [
    "円周率 π は無理数で、循環しない無限小数です。",
    "オイラーの公式 e^{iπ}+1=0 は、5つの基本定数を結びつけます。",
    "素数は無限に存在することをユークリッドが紀元前に証明しました。",
    "シェルピンスキー三角形は自己相似性をもつ代表的なフラクタルです。",
    "テイラー展開で sin, cos, e^x を無限級数として表せます。",
    "1/2 + 1/4 + 1/8 + … は 1 に収束します（幾何級数）。",
    "コッホ曲線の長さは無限大ですが面積は有限です。",
    "黄金比 φ ≈ 1.618 は連分数 [1;1,1,1,…] として表現できます。",
    "素数定理は π(x) ~ x / ln x を与えます。",
    "円の面積は πr²、円周は 2πr です。"
  ];
  function showToast(msg){
    const t = el('#toast');
    t.textContent = msg;
    t.style.display = 'block';
    clearTimeout(t._hide);
    t._hide = setTimeout(()=>t.style.display='none', 2600);
  }
  G.onPurchaseToast = function(item){
    showToast(`「${item.name}」を購入！ — ${facts[Math.floor(Math.random()*facts.length)]}`);
  };

  /* ----- Modals, stats & achievements ----- */
  const modalStats = el('#modalStats');
  const modalAchv = el('#modalAchv');
  el('#openStats').addEventListener('click', ()=>openModal(modalStats));
  el('#openAchv').addEventListener('click', ()=>openModal(modalAchv));
  document.body.addEventListener('click', e=>{
    const closeBtn = e.target.closest('[data-close]');
    if(closeBtn){ closeModal(el(closeBtn.dataset.close)); }
    if(e.target.classList.contains('scrim')){
      const parent = e.target.closest('.modal'); if(parent) closeModal(parent);
    }
  });
  function openModal(m){ m.style.display='grid'; refreshModals(); }
  function closeModal(m){ m.style.display='none'; }

  function refreshModals(){
    el('#mPiNow').textContent = 'π×'+G.fmt(G.state.pi);
    el('#mCps').textContent = 'π×'+G.fmt(G.state.cpsBase * G.state.cpsBonusMult);
    el('#mClickVal').textContent = `+π×${G.fmt(G.state.clickValue*G.state.clickBonusMult)} /クリック`;
    el('#mClicks').textContent = G.state.totalClicks;
    el('#mTotal').textContent = 'π×'+G.fmt(G.state.totalPi);
    el('#mPrimes').textContent = G.state.primesDiscovered;
    el('#mPiDigits').textContent = `${G.state.maxPiDigits} 桁`;
    el('#mEvent').textContent = G.state.event ? `${G.state.event.label}（${G.state.event.detail}）` : 'なし';
    renderAchievements();
  }
  G.refreshModals = refreshModals;

  const achvDefs = [
    {id:'click_100', name:'クリック入門', cond:'クリック100回', check:()=>G.state.totalClicks>=100},
    {id:'click_1000', name:'クリック達人', cond:'クリック1000回', check:()=>G.state.totalClicks>=1000},
    {id:'pi_1k', name:'円周初心者', cond:'累計 π×1,000 到達', check:()=>G.state.totalPi>=1000},
    {id:'pi_1m', name:'円周研究家', cond:'累計 π×1,000,000 到達', check:()=>G.state.totalPi>=1e6},
    {id:'spirit_10', name:'桁の番人', cond:'π精霊 ×10', check:()=>G.state.items.spirit.count>=10},
    {id:'prime_100', name:'素数収集家', cond:'素数を100個発見', check:()=>G.state.primesDiscovered>=100},
    {id:'frac_10', name:'庭園管理人', cond:'フラクタル庭園 ×10', check:()=>G.state.items.fractal.count>=10},
    {id:'series_10', name:'修道院の合唱', cond:'無限級数の修道士 ×10', check:()=>G.state.items.series.count>=10},
  ];

  function renderAchievements(){
    const tbl = el('#achvTable');
    // ensure header exists
    if(!tbl.querySelector('tr')){
      const trh = document.createElement('tr');
      trh.innerHTML = '<th>実績</th><th>条件</th><th>状態</th>';
      tbl.appendChild(trh);
    }
    // Clear rows except header
    tbl.querySelectorAll('tr:not(:first-child)').forEach(tr=>tr.remove());
    for(const a of achvDefs){
      const ok = a.check();
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${a.name}</td><td class="small">${a.cond}</td><td>${ ok? '✅ 解放':'⏳ 未達'}</td>`;
      tbl.appendChild(tr);
    }
  }

  // Start after DOM ready
  window.addEventListener('DOMContentLoaded', ()=>{
    G.updateTop();
    if(G.renderShop) G.renderShop();
    G.start();
  });
})();