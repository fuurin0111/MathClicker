// Visual modules: pi digits, prime stream, waves, fractal, series
(function(){
  const G = window.Game;
  const el = G.el;

  // π digits progression (based on spirits)
  const piDigits =
  "14159265358979323846264338327950288419716939937510"+
  "58209749445923078164062862089986280348253421170679"+
  "82148086513282306647093844609550582231725359408128"+
  "48111745028410270193852110555964462294895493038196"+
  "44288109756659334461284756482337867831652712019091"+
  "45648566923460348610454326648213393607260249141273";

  function updatePiDigits(){
    const spirits = G.state.items.spirit.count;
    if(spirits<=0){ el('#piDigitsText').textContent = '—'; return; }
    const digits = Math.min(2 + Math.max(0, spirits-1), piDigits.length); // 1体→3.14（2桁）
    const txt = '3.' + piDigits.slice(0, digits);
    el('#piDigitsText').textContent = txt;
    G.state.maxPiDigits = Math.max(G.state.maxPiDigits, digits);
  }
  setInterval(updatePiDigits, 500);

  // Prime ticker
  let primeCurrent = 1;
  function isPrime(n){
    if(n<2) return false;
    if(n%2===0) return n===2;
    for(let i=3;i*i<=n;i+=2) if(n%i===0) return false;
    return true;
  }
  function nextPrime(n){ let k=n+1; while(!isPrime(k)) k++; return k; }
  function updatePrime(){
    if(G.state.items.prime.count<=0) return;
    primeCurrent = nextPrime(primeCurrent);
    G.state.primesDiscovered++;
    el('#primeStream').textContent = primeCurrent.toString();
  }
  setInterval(updatePrime, 1000);

  // Trig waves
  const waveCanvas = el('#waveCanvas');
  const wctx = waveCanvas.getContext('2d');
  function drawWaves(){
    const W = waveCanvas.width, H = waveCanvas.height;
    wctx.clearRect(0,0,W,H);
    wctx.lineWidth = 2;
    // axis
    wctx.strokeStyle = '#12344f';
    wctx.beginPath(); wctx.moveTo(0, H/2); wctx.lineTo(W, H/2); wctx.stroke();

    function draw(f, phase, amp, color, t){
      wctx.beginPath();
      for(let x=0;x<W;x++){
        const y = H/2 + Math[f](x*0.02 + phase + t*0.004) * amp;
        if(x===0) wctx.moveTo(x,y); else wctx.lineTo(x,y);
      }
      wctx.strokeStyle = color; wctx.stroke();
    }
    const t = performance.now();
    const level = 1 + G.state.items.trig.count;
    draw('sin', 0, 20+level*2, '#9bd2ff', t);
    draw('cos', 1.2, 14+level*1.5, '#e6b400', t);
    requestAnimationFrame(drawWaves);
  }
  requestAnimationFrame(drawWaves);

  // Fractal (Sierpinski via chaos game)
  const fractalCanvas = el('#fractalCanvas');
  const fctx = fractalCanvas.getContext('2d');
  let fp1, fp2, fp3, fpt;
  function resetFractal(){
    const W = fractalCanvas.width, H = fractalCanvas.height;
    fctx.fillStyle = '#061526'; fctx.fillRect(0,0,W,H);
    fctx.fillStyle = '#58ecdd';
    fp1 = {x: W*0.5, y: 10};
    fp2 = {x: 10, y: H-10};
    fp3 = {x: W-10, y: H-10};
    fpt = {x: W*0.5, y: H*0.5};
  }
  resetFractal();
  function stepFractal(){
    const count = Math.max(100, G.state.items.fractal.count*120);
    for(let i=0;i<count;i++){
      const target = [fp1,fp2,fp3][Math.floor(Math.random()*3)];
      fpt = {x: (fpt.x + target.x)/2, y: (fpt.y + target.y)/2};
      fctx.fillRect(fpt.x, fpt.y, 1, 1);
    }
    requestAnimationFrame(stepFractal);
  }
  requestAnimationFrame(stepFractal);

  // Series (1/2^n)
  let seriesN = 0;
  function updateSeries(){
    const monks = G.state.items.series.count;
    seriesN = (seriesN + Math.max(1, monks)) % 60;
    let sum = 0, n = seriesN;
    for(let k=1;k<=n;k++) sum += Math.pow(0.5,k);
    const ratio = Math.min(1, sum);
    el('#seriesFill').style.width = (ratio*100).toFixed(1)+'%';
    el('#seriesLine').textContent = `Sₙ = ${sum.toFixed(3)} ／ 1`;
  }
  setInterval(updateSeries, 800);

  // Hook special animation
  window.Game.onSpecialAnimation = function(key){
    if(key==='fractal') resetFractal();
  };
})();